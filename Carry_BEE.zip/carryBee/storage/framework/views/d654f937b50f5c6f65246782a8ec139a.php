<script>
    window.location.href = "/login";
</script><?php /**PATH C:\xampp\htdocs\All_Fie\Carry_BEE\carryBee\resources\views/welcome.blade.php ENDPATH**/ ?>