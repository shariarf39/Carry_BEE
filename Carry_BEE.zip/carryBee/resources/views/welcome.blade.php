<script>
    window.location.href = "/login";
</script>